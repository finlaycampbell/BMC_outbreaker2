library(testthat)
library(outbreaker2)

test_check("outbreaker2")
